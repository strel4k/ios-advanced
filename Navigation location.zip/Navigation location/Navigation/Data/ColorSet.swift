//
//  ColorSet.swift
//  Navigation
//
//  Created by Alexander on 24.05.2022.
//

import UIKit

struct ColorSet {
    static let mainColor = UIColor(named: "main_color")
}
