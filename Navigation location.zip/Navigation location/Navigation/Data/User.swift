//
//  User.swift
//  Navigation
//
//  Created by Alexander on 28.05.2022.
//

import Foundation
import UIKit


class User {
    
    let fullName: String
    let avatar: UIImage?
    let status: String
    
    init(fullName: String, avatar: UIImage, status: String) {
        self.fullName = fullName
        self.avatar = avatar
        self.status = status
    }
}

protocol UserService {
    
    func userService(name: String) -> User?
    
}

class CurrentUserService: UserService {
    
    let user = User(fullName: "Bruce", avatar: UIImage(named: "avatar")!, status: "MEOW")
    func userService(name: String) -> User? {
        guard name == user.fullName else {
            return nil
        }
        return self.user
    }
}

class TestUserService: UserService {
    
    let user = User(fullName: "Bruce The Catman", avatar: UIImage(named: "catman")!, status: "I'm a justice")
    
    func userService(name: String) -> User? {
//        guard name == user.fullName else {
//            return nil
//        }
        return self.user
    }
}

