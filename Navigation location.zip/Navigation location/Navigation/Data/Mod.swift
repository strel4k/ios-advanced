//
//  Mod.swift
//  Navigation
//
//  Created by Alexander on 24.06.2022.
//

import Foundation
import UIKit

final class Model {
    
    let password = "Brc"
    
    func check(word: String) {
        guard word != "" else { return }
        
        if word == password {
            NotificationCenter.default.post(name: NSNotification.Name.codeGreen, object: nil)
        } else {
            NotificationCenter.default.post(name: NSNotification.Name.codeRed, object: nil)
        }
    }
    
    private lazy var passwordAlert: UIAlertController = {
        let alertController = UIAlertController(
            title: "Nah!",
            message: "",
            preferredStyle: .alert)
                
        alertController.addAction(UIAlertAction(title: "heh", style: .default))
        return alertController
    }()
}
