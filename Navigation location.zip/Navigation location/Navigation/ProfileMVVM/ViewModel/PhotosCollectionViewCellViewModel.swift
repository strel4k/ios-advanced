//
//  PhotosCollectionViewCellViewModel.swift
//  Navigation
//
//  Created by Alexander on 29.06.2022.
//

import Foundation
import UIKit

class PhotosCollectionViewCellViewModel {
    
    var image: UIImage
    
    init (image: UIImage) {
        self.image = image
    }
}
