//
//  ProfileViewModel.swift
//  Navigation
//
//  Created by Alexander on 29.06.2022.
//

import Foundation
import UIKit

final class ProfileViewModel {
    public var posts = [
    
    Post(author: "bruce.official",
                      title: "Yeeeeeaaah",
                      description: "We already have a 1 000 000",
                      image: UIImage(named: "post_1")!,
                      likes: 96928,
         views: 600000, personalID: "fghjkjhgfghjklkjh"),
    Post(author: "bbc.news",
                      title: "Sunshine",
                      description: "New photo of the Sun",
                      image: UIImage(named: "post_2")!,
                      likes: 21312,
         views: 32123, personalID: "vbnm,mnbvhjmk"),
    Post(author: "oskar.fun",
                      title: "my 2022",
                      description: "Hello from WS",
                      image: UIImage(named: "post_3")!,
                      likes: 123123,
         views: 332123, personalID: "tgbjm,ol.jhgfdcvg"),
    Post(author: "reddit",
                      title: "Morbius is here",
                      description: "Jared Leto on grammy awards",
                      image: UIImage(named: "post_4")!,
                      likes: 5621312,
         views: 7732123, personalID: "gvhbjnkmlvctyyuhjbuty")
]
    
    func numberOfRows() -> Int {
        return posts.count
    }
    
    func cellViewModel(forIndexPath indexPath: IndexPath) -> PostTableViewCellViewModel? {
        let post = posts[indexPath.row]
        return PostTableViewCellViewModel(post: post)
    }
}
