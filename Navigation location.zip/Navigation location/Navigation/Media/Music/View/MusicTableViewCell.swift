//
//  MusicTableViewCell.swift
//  Navigation
//
//  Created by Alexander on 08.08.2022.
//

import UIKit

class MusicTableViewCell: UITableViewCell {

    private lazy var trackNameLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    private lazy var musicIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(systemName: "music.note", withConfiguration: UIImage.SymbolConfiguration(pointSize: 32))?.withTintColor(.black, renderingMode: .alwaysOriginal)
        return image
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubviews(trackNameLabel, musicIcon)
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
 
    func setupLayout() {
                
        musicIcon.snp.makeConstraints { make in
            make.leading.top.bottom.equalToSuperview().inset(12)
        }
        
        trackNameLabel.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(12)
            make.leading.equalTo(musicIcon.snp.trailing).offset(12)
        }
    }
    
    func setConfigureOfCell(model: MusicViewModel, index: Int) {
        
        var currentTrackName: String {
            get {
                let artist = Array(MusicViewModel.tracklist.values)[index]
                let track = Array(MusicViewModel.tracklist.keys)[index]
                return "\(artist) - \(track)"
            }
        }
        
        trackNameLabel.text = currentTrackName
    }

}
