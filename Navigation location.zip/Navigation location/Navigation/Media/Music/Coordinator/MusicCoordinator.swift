//
//  MusicCoordinator.swift
//  Navigation
//
//  Created by Alexander on 08.08.2022.
//

import UIKit

final class MusicCoordinator {
    func showDetail(coordinator: MusicCoordinator) -> UIViewController {
        let viewModel = MusicViewModel()
        let viewController = MusicViewController(model: viewModel, coordinator: coordinator)
        viewController.view?.backgroundColor = .secondarySystemGroupedBackground
        viewController.title = "Музыка"
        return viewController
    }
}
