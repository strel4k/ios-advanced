//
//  VideoPlayer.swift
//  Navigation
//
//  Created by Alexander on 08.08.2022.
//

//import UIKit
//import YouTubeiOSPlayerHelper
//import SnapKit
//
//class VidePlayerViewController: UIViewController {
//
//    private var videoKey: String
//
//    private lazy var playerView: YTPlayerView = {
//        let player = YTPlayerView()
//        return player
//    }()
//
//    init (videoKey: String) {
//        self.videoKey = videoKey
//        super.init(nibName: nil, bundle: nil)
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        playerView.delegate = self
//        playerView.load(withVideoId: videoKey, playerVars: ["playsinline": "1"])
//        setupLayout()
//    }
//
//    private func setupLayout() {
//
//        view.addSubview(playerView)
//
//        playerView.snp.makeConstraints { make in
//            make.center.equalToSuperview()
//            make.width.equalToSuperview()
//            make.height.equalTo(view.frame.size.width / 1.78)
//        }
//    }
//}
//
//extension VidePlayerViewController: YTPlayerViewDelegate {
//    func playerViewPreferredWebViewBackgroundColor(_ playerView: YTPlayerView) -> UIColor {
//        return UIColor.black
//    }
//
//}
