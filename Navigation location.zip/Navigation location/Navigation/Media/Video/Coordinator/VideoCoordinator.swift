//
//  VideoCoordinator.swift
//  Navigation
//
//  Created by Alexander on 08.08.2022.
//

import UIKit

final class VideoCoordinator {
    func showDetail(coordinator: VideoCoordinator) -> UIViewController {
        let viewModel = VideoViewModel()
        let viewController = VideoViewController(model: viewModel, coordinator: coordinator)
        viewController.view.backgroundColor = .secondarySystemGroupedBackground
        viewController.title = "Видео"
        return viewController
    }
}

////final class VideoPlayerCoordinator {
////    func showDetail(navCon: UINavigationController?, coordinator: VideoPlayerCoordinator, key: String) {
////        let viewController = VideoPlayerViewController(videoKey: key)
////        viewController.view.backgroundColor = .systemGray5
////        viewController.title = VideoViewModel.videos[key]
////        navCon?.pushViewController(viewController, animated: true)
////    }
//}
