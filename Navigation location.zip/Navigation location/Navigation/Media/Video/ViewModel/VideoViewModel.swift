//
//  VideoViewModel.swift
//  Navigation
//
//  Created by Alexander on 08.08.2022.
//

import UIKit
import AVKit

final class VideoViewModel {
    
    static var videos: [String: String] = [
        "izGwDsrQ1eQ" : "George Michael - Careless whisper",
        "7YuAzR2XVAM" : "Eminem - Lose yourself",
        "QQ55ywJwF1Q" : "Barry White - Never never gonna give ya up",
        "nJkrQfN15w4" : "Journey - Separate ways",
        "h_D3VFfhvs4" : "Michael Jackson - Smooth criminal"
    ]
        
    private lazy var streamURL = URL(string: "https://www.youtube.com/watch?v=dQw4w9WgXcQ")!

    private lazy var localURL: URL = {
        let path = Bundle.main.path(forResource: "test", ofType: "mp4")!
        return URL(fileURLWithPath: path)
    }()

    func playButtonPressed(navController: UINavigationController) {
        
        let player = AVPlayer(url: streamURL)
        let controller = AVPlayerViewController()
        controller.player = player
        navController.present(controller, animated: true) {
            player.play()
        }
    }

}
