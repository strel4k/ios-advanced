//
//  LoginInspector.swift
//  Navigation
//
//  Created by Alexander on 25.08.2022.
//

import Foundation

class LoginInspector: LoginViewControllerDelegate {
    
    func signing (signType: SignType, log: String, pass: String) {
        Checker.shared.checkUser( signType: signType, log: log, pass: pass)
    }
}
