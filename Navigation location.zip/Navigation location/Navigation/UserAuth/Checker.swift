//
//  Checker.swift
//  Navigation
//
//  Created by Alexander on 31.05.2022.
//

import Foundation

enum SignType {
    case signIn
    case signUp
}

final class Checker {
    
    static let shared = Checker()
    
    var completion: ((_ message: String) -> Void)?
        
    private init() {}
    
    public func checkUser (signType: SignType, log: String, pass: String) {
        

    }
}

