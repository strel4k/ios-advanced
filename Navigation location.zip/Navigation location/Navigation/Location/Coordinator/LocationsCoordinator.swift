//
//  LocationsCoordinator.swift
//  Navigation
//
//  Created by Mac on 06.10.2022.
//

import UIKit

final class LocationsCoordinator {
    func showDetail(coordinator: LocationsCoordinator) -> UIViewController {
        let viewController = LocationsViewController(coordinator: coordinator)
        viewController.view.backgroundColor = .secondarySystemGroupedBackground
        viewController.title = "Locations"
        return viewController
    }
}
