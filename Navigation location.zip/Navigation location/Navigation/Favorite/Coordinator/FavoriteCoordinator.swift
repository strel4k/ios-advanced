//
//  FavoriteCoordinator.swift
//  Navigation
//
//  Created by Mac on 11.09.2022.
//

import UIKit

final class FavoriteCoordinator {
    func showDetail(coordinator: FavoriteCoordinator) -> UIViewController {
        let viewController = FavoriteViewController(coordinator: coordinator)
        viewController.view.backgroundColor = .secondarySystemGroupedBackground
        viewController.title = "Favorite posts"
        return viewController
    }
}
