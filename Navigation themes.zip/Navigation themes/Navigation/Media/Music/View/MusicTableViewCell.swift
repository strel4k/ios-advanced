//
//  MusicTableViewCell.swift
//  Navigation
//
//  Created by Alexander on 08.08.2022.
//

import UIKit
import SnapKit

class MusicTableViewCell: UITableViewCell {
    
    private lazy var trackNameLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    private lazy var musicIcon: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(systemName: "music.note", withConfiguration: UIImage.SymbolConfiguration(pointSize: 32))?.withTintColor(.black, renderingMode: .alwaysOriginal)
        return image
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubviews(trackNameLabel, musicIcon)
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        apply(theme: traitCollection.userInterfaceStyle == .light ? .light : .dark)
    }
    
    func setupLayout() {
        
        apply(theme: traitCollection.userInterfaceStyle == .light ? .light : .dark)
        
        musicIcon.snp.makeConstraints { make in
            make.leading.top.bottom.equalToSuperview().inset(12)
        }
        
        trackNameLabel.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(12)
            make.leading.equalTo(musicIcon.snp.trailing).offset(12)
        }
    }
    
    func setConfigureOfCell(model: MusicViewModel, index: Int) {
        
        var currentTrackName: String {
            get {
                let singer = Array(MusicViewModel.tracklist.values)[index]
                let track = Array(MusicViewModel.tracklist.keys)[index]
                return "\(singer) - \(track)"
            }
        }
        
        trackNameLabel.text = currentTrackName
    }
}

extension MusicTableViewCell: Themeable {
    
    func apply(theme: Theme) {
        self.contentView.backgroundColor = theme.colors.palette.cell
        self.trackNameLabel.textColor = theme.colors.palette.text
        self.musicIcon.tintColor = theme.colors.palette.foregroud
    }
}
