//
//  InfoViewModel.swift
//  Navigation
//
//  Created by Alexander on 29.06.2022.
//

import Foundation
import UIKit
import SnapKit

final class InfoViewModel {

    var infoAlert: UIAlertController {
        let alertController = UIAlertController(title: AlertLabelsText.attentionLabel, message: AlertMessageText.doYouLikeText, preferredStyle: .alert)
        let acceptAction = UIAlertAction(title: AlertButtonText.yesButton, style: .default) { _ in
            print("ty")
        }
        let declineAction = UIAlertAction(title: AlertButtonText.noButton, style: .destructive) { _ in
            print("not ty")
        }
        alertController.addAction(acceptAction)
        alertController.addAction(declineAction)
        
        return alertController
    }

    func presentAlert (viewController: UIViewController) {
        viewController.present(infoAlert, animated: true, completion: nil)
    }

}
