//
//  InfoModel.swift
//  Navigation
//
//  Created by Alexander on 16.08.2022.
//

import Foundation

public struct InfoModel: Codable {
    var userId: Int
    var id: Int
    var title: String
    var completed: Bool
}
