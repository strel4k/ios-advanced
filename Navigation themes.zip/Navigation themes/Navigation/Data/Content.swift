//
//  Content.swift
//  Navigation
//
//  Created by Alexander on 04.08.2022.
//

import UIKit
import iOSIntPackage

enum Errors: Error {
    case notFound
    case unauthorized
    case badData
    case unowned
}

final class Content {
    static let shared = Content()
    private let imageProcessor = ImageProcessor()
    private let filtersSet: [ColorFilter] = [.fade, .posterize, .chrome, .noir, .colorInvert, .tonal, .process, .transfer, .bloom(intensity: 8), .sepia(intensity: 60)]
    public let photosArray = (1...4).compactMap {"p_\($0)"}
    public let threadPhotosArray = (1...4).compactMap {UIImage(named: "p_\($0)")}
    public var filtredPhotosArray: [UIImage] = []
    
    public func createPhotosArray() {
        for i in photosArray {
            guard let pic = UIImage(named: i) else {return}
            filtredPhotosArray.append(makeFiltredImage(pic))
        }
    }
    public func makeFiltredImage(_ image: UIImage) -> UIImage {
        var newImage = UIImage()
        imageProcessor.processImage(sourceImage: image, filter: getRandomFilter(set: filtersSet)) { filtredImage in
            newImage = filtredImage ?? UIImage()
    }
        return newImage
}
    private func getRandomFilter (set: [ColorFilter]) -> ColorFilter {
        let randomFilterNumber = Int.random(in: 0..<set.count)
        return set[randomFilterNumber]
    }
}
