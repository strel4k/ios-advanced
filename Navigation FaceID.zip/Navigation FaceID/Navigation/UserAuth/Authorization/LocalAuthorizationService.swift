//
//  LocalAuthorizationService.swift
//  Navigation
//
//  Created by Mac on 07.11.2022.
//

import Foundation
import LocalAuthentication
import UIKit

final class LocalAuthorizationService {
    static var shared = LocalAuthorizationService()
    private var context = LAContext()
    private let policy: LAPolicy = .deviceOwnerAuthenticationWithBiometrics
    private var error: NSError?
    private var canUserBiometric = false
    
    public var availableAuthorizationType: LABiometryType
    
    private init() {
        self.canUserBiometric = context.canEvaluatePolicy(policy, error: &self.error)
        self.availableAuthorizationType = context.biometryType
    }
    public func authorizeIfPossible(_ authorizationFinished: @escaping (Bool, Error?) -> Void) {
        
        guard canUserBiometric else { return }
        
        context.evaluatePolicy(policy, localizedReason: "auth.getAuth".localized) { success, error in
            
            DispatchQueue.main.async {
                if success { authorizationFinished(self.canUserBiometric, error) }
            }
        }
    }
}
