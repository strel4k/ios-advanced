//
//  LoginViewControllerDelegate.swift
//  Navigation
//
//  Created by Alexander on 25.08.2022.
//

import Foundation

protocol LoginViewControllerDelegate: AnyObject {
    
    func signing (signType: SignType, log: String, pass: String)
    
}
