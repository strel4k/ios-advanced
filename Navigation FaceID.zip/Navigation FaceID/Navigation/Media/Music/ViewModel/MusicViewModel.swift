//
//  MusicViewModel.swift
//  Navigation
//
//  Created by Alexander on 08.08.2022.
//

import UIKit

final class MusicViewModel {
    static var tracklist: [String:String] = [
        "Careless whisper" : "George Michael",
        "Lose yourself" : "Eminem",
        "Never never gonna give ya up" : "Barry White",
        "Separate ways" : "Journey",
        "Smooth criminal" : "Michael Jackson"
        ]
}
