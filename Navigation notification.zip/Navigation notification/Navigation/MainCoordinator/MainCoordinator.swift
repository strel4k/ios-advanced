//
//  MainCoordinator.swift
//  Navigation
//
//  Created by Alexander on 29.06.2022.
//

import UIKit

final class MainCoordinator {
    func startingApp() -> UIViewController {
        return MainTabBarViewController()
    }
}
