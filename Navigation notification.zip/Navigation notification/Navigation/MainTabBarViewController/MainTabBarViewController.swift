//
//  MainTabBarViewController.swift
//  Navigation
//
//  Created by Alexander on 29.06.2022.
//

import UIKit

class MainTabBarViewController: UITabBarController {
    
    private let feedViewController = Factory(navigationController: UINavigationController(), state: .feed)
    private let profileViewController = Factory(navigationController: UINavigationController(), state: .profile)
    private let loginViewController = Factory(navigationController: UINavigationController(), state: .login)
    private let locationsViewController = Factory(navigationController: UINavigationController(), state: .locations)
    private let favoriteViewController = Factory(navigationController: UINavigationController(), state: .favorite)
    private let musicViewController = Factory(navigationController: UINavigationController(), state: .music)
    private let videoViewController = Factory(navigationController: UINavigationController(), state: .video)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.backgroundColor = UIColor.systemGray5

        setControllers()
    }
    
    private func setControllers() {
        viewControllers = [
            feedViewController.navigationController,
            loginViewController.navigationController,
            locationsViewController.navigationController,
            favoriteViewController.navigationController,
            musicViewController.navigationController,
            videoViewController.navigationController
        
        ]
    }

}
