//
//  LoginFactoryProtocol.swift
//  Navigation
//
//  Created by Alexander on 25.08.2022.
//

import Foundation

protocol LoginFactory {
    
    func returnLoginInspector() -> LoginViewControllerDelegate
    
}
