//
//  LoginFactory.swift
//  Navigation
//
//  Created by Alexander on 25.08.2022.
//

import Foundation

class MyLoginFactory: LoginFactory {
    
    static let shared = MyLoginFactory()
    
    func returnLoginInspector() -> LoginViewControllerDelegate {
         let inspector = LoginInspector()
         return inspector
     }
}
