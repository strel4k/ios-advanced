//
//  PostModel.swift
//  Navigation
//
//  Created by Alexander on 29.06.2022.
//

import Foundation
import UIKit

struct Post {
    
    var author: String
    var title: String
    var description: String
    var image: UIImage
    var likes: Int
    var views: Int
    var personalID: String

}
