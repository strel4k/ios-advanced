//
//  AppDelegate.swift
//  Navigation
//
//  Created by Alexander on 24.05.2022.
//

import UIKit
import CoreData
import UserNotifications

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    let inspector = MyLoginFactory.shared.returnLoginInspector()
        
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        LocalNotificationsService.shared.registerForLatestUpdatesIfPossible()
        LocalNotificationsService.shared.registerUpdatesCategory()
        
        window = UIWindow(frame: UIScreen.main.bounds)
        
        let url = AppConfiguration.randomURL()
        
        let mainCoordinator = MainCoordinator()
        DispatchQueue.global().async {
            Content.shared.createPhotosArray()
        }
        
        NetworkService.urlSession(stringURL: url)
        
        InfoNetworkManager.shared.urlSession()
        PlanetsNetworkManager.shared.fetchPlanetsData()
        
        window?.rootViewController = mainCoordinator.startingApp()
        window?.makeKeyAndVisible()
        
        return true
    }
}
