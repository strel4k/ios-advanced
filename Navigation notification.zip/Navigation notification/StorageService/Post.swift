//
//  Post.swift
//  Navigation
//
//  Created by Alexander on 24.05.2022.
//

import UIKit

public struct somePost {
    
    public var author: String
    public var title: String
    public var description: String
    public var image: String
    public var likes: Int
    public var views: Int
}
